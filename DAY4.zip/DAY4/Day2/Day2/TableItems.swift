//
//  TableItems.swift
//  Day2
//
//  Created by MacStudent on 2018-08-09.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class TableItems{
    static var Titles : [ String] = ["audio","video","webview","calender","location","contacts"]
    static var subtitles : [String] = ["soul music", "watch it better", "world is yours", "time is not yours","be everywhere","stay connected"]
    static var images: [String] = ["audio", "video", "web", "calendar", "location", "contacts"]
    
    
}

